package com.prassistant.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import android.graphics.Typeface
import android.view.WindowManager.LayoutParams
import kotlin.random.Random

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var stats: TextView
    private lateinit var timer: TextView
    private var count = 0
    private var running = false
    private var seconds = 0
    private var remaining = 0
    private var delayRangeMin = 25
    private var delayRangeMax = 55
    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!::wm.isInitialized) createPanel()
        return START_NOT_STICKY
    }

    private fun label(text: String, size: Float = 14f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        setPadding(7, 5, 7, 5)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(25, 30, 38))
        }
        val heading = label("PR ASSISTANT   ⋮", 17f).apply { setTypeface(null, Typeface.BOLD) }
        stats = label("Tâches validées : 0", 14f)
        timer = label("Prochain rappel : —   |   Session : 00:00", 12f)
        val row1 = LinearLayout(this)
        row1.addView(button("+1 tâche", ::addTask), LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(button("Pause", ::pauseSession), LinearLayout.LayoutParams(0, -2, 1f))
        val row2 = LinearLayout(this)
        row2.addView(button("Démarrer", ::startSession), LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(button("Repos 5 min", ::rest), LinearLayout.LayoutParams(0, -2, 1f))
        val row3 = LinearLayout(this)
        row3.addView(button("Réinitialiser", ::reset), LinearLayout.LayoutParams(0, -2, 1f))
        row3.addView(button("Fermer", ::closePanel), LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(heading); panel.addView(stats); panel.addView(timer)
        panel.addView(row1); panel.addView(row2); panel.addView(row3)

        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE
        val params = LayoutParams(310, LayoutParams.WRAP_CONTENT, type,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12; y = 120
        }
        wm.addView(panel, params)
        // Drag the panel by long-pressing its header.
        heading.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = params.x; startY = params.y
                        return true
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        params.x = startX - (e.rawX - downX).toInt()
                        params.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(panel, params); return true
                    }
                }
                return true
            }
        })
    }

    private fun addTask() { count++; update() }
    private fun startSession() {
        if (running) return
        running = true
        scheduleDelay()
        ticker = object : Runnable {
            override fun run() {
                if (running) { seconds++; if (remaining > 0) remaining--; update(); handler.postDelayed(this, 1000) }
            }
        }
        handler.post(ticker!!)
        update()
    }
    private fun scheduleDelay() { remaining = Random.nextInt(delayRangeMin, delayRangeMax + 1); update() }
    private fun pauseSession() { running = false; ticker?.let { handler.removeCallbacks(it) }; remaining = 0; update() }
    private fun rest() {
        pauseSession()
        remaining = 300
        Toast.makeText(this, "Pause de repos de 5 minutes lancée", Toast.LENGTH_SHORT).show()
        val restTicker = object : Runnable {
            override fun run() {
                if (remaining > 0) { remaining--; update(); handler.postDelayed(this, 1000) }
                else { Toast.makeText(this, "Pause terminée", Toast.LENGTH_SHORT).show(); update() }
            }
        }
        handler.post(restTicker)
    }
    private fun reset() { pauseSession(); count = 0; seconds = 0; update() }
    private fun update() {
        if (!::stats.isInitialized) return
        stats.text = "Tâches validées : $count"
        val m = seconds / 60; val s = seconds % 60
        val wait = if (remaining > 0) String.format("%02d:%02d", remaining / 60, remaining % 60) else "—"
        timer.text = "Rappel/repos : $wait   |   Session : %02d:%02d".format(m, s)
    }
    private fun closePanel() { pauseSession(); if (::panel.isInitialized) wm.removeView(panel); stopSelf() }
    override fun onDestroy() { ticker?.let { handler.removeCallbacks(it) }; super.onDestroy() }
}
