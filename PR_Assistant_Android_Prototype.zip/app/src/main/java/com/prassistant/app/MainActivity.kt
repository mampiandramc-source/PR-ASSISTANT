package com.prassistant.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(16, 19, 24))
        }
        val title = TextView(this).apply {
            text = "PR ASSISTANT"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Mini-panneau flottant pour organiser tes sessions et suivre tes tâches manuellement."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 24)
        }
        val permission = Button(this).apply { text = "Autoriser l'affichage par-dessus les applis" }
        permission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else startPanel()
        }
        val launch = Button(this).apply { text = "Afficher le mini-écran" }
        launch.setOnClickListener {
            if (Settings.canDrawOverlays(this)) startPanel()
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        val note = TextView(this).apply {
            text = "Le panneau aide à compter, temporiser et organiser les tâches. Il ne clique pas sur Follow, ne pilote pas Instagram Lite et ne contourne pas les restrictions."
            textSize = 13f
            setTextColor(Color.rgb(180, 190, 200))
            setPadding(0, 24, 0, 0)
        }
        root.addView(title); root.addView(desc); root.addView(permission); root.addView(launch); root.addView(note)
        setContentView(root)
    }

    private fun startPanel() {
        startService(Intent(this, FloatingPanelService::class.java))
        finish()
    }
}
